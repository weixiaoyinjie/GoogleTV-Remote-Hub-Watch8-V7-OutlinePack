package com.cecbridge.remotev2;

/** Pure geometry, shared by drawing and hit testing. All dimensions are pixels. */
final class RoundPanelGeometry {
    // Clockwise from top. Slightly tighter spacing in the lower, smaller crescent.
    private static final double[] ANGLES={-90,-48,-8,32,72,108,148,188,232};
    final float sx,sy,cx,cy,screenRadius,wheel,ok,gap;
    final float[] x=new float[ANGLES.length],y=new float[ANGLES.length],r=new float[ANGLES.length];

    RoundPanelGeometry(float width,float height,float edgeInset,float requestedGap){
        sx=width*.5f;sy=height*.5f;
        screenRadius=Math.max(0,Math.min(width,height)*.5f-edgeInset);
        wheel=screenRadius*.59f*1.15f; // V6 diameter +15% at the same usable radius.
        ok=wheel*.34f;                // Smaller than the V6 absolute OK radius.
        cx=sx;cy=sy+screenRadius*.06f;
        gap=Math.max(0,Math.min(requestedGap,screenRadius*.025f));
        double wx=cx-sx,wy=cy-sy,R=screenRadius,W=wheel+gap;
        for(int i=0;i<ANGLES.length;i++){
            double a=Math.toRadians(ANGLES[i]);
            double ux=Math.cos(a),uy=Math.sin(a),dot=wx*ux+wy*uy;
            // Center at (R-r)*u. Solve |(R-r)*u-w| = W+r.
            // This gives the largest circle along this ray, tangent to the
            // safe screen edge and separated from the wheel by gap.
            double den=2*(R-dot+W);
            r[i]=den>0?(float)Math.max(0,(R*R-2*R*dot+wx*wx+wy*wy-W*W)/den):0;
            x[i]=sx+(screenRadius-r[i])*(float)ux;
            y[i]=sy+(screenRadius-r[i])*(float)uy;
        }
    }

    int hitKey(float px,float py){
        for(int i=0;i<x.length;i++){
            float dx=px-x[i],dy=py-y[i];
            if(r[i]>0&&dx*dx+dy*dy<=r[i]*r[i])return i;
        }
        return -1;
    }

    // 0: outside, 1: OK, 2: up, 3: down, 4: left, 5: right.
    int hitWheel(float px,float py){
        if(wheel<=0)return 0;
        float dx=px-cx,dy=py-cy,d2=dx*dx+dy*dy;
        if(d2>wheel*wheel)return 0;
        if(d2<=ok*ok)return 1;
        if(Math.abs(dx)>Math.abs(dy))return dx<0?4:5;
        return dy<0?2:3;
    }
}
